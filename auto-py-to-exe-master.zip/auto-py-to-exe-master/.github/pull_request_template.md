👋 Hello there! Welcome. Please follow the steps below to select a template.

1. Go the the `Preview` tab
2. Select the appropriate sub-template
   - [✨ A new feature](?expand=1&template=feature.md)
   - [📄 A new or updated translation](?expand=1&template=translation.md)
3. Fill all sections in the template
4. Click "Create pull request"
