import os
import random

# Set your custom output directory
output_dir = r"C:\Users\Fayad\OneDrive\Desktop\path"

# Make sure the directory exists
os.makedirs(output_dir, exist_ok=True)

# List of real file types only (no unknowns)
file_types = {
    "excel": [".xlsx"],
    "word": [".docx"],
    "powerpoint": [".pptx"],
    "text": [".txt"],
    "audio": [".mp3", ".wav"],
    "video": [".mp4", ".mov"],
    "image": [".png", ".jpeg", ".jpg", ".gif"],
    "pdf": [".pdf"],
    "html": [".html"],
}

# How many total files to create
num_files = 50

# Randomly create 50 files
for i in range(1, num_files + 1):
    category = random.choice(list(file_types.keys()))
    extension = random.choice(file_types[category])
    file_name = f"testfile_{i}{extension}"
    file_path = os.path.join(output_dir, file_name)
    with open(file_path, 'w') as f:
        f.write(f"This is a dummy file: {file_name}")

print(f"✅ Created {num_files} test files in: {output_dir}")